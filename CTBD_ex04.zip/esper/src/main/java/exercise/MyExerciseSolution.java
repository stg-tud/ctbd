package exercise;

import java.util.HashSet;
import java.util.Set;

public class MyExerciseSolution extends Exercise {

	@Override
	protected Set<String> generateIntermediateRules() {
		final Set<String> rules = new HashSet<>();
		// Populate rules with your EPL rules
		return rules;
	}

	@Override
	protected String generateOutputRule() {
		final String rule = "";
		// Write your rule in the rule variable
		return rule;
	}

	@Override
	protected void generateIntermedateStreams() {
		// Create accessory streams here by invoking the generateStream() method
	}

	@Override
	protected void sendEvents() {
		// You can send events using the inherited methods
		//
		// sendPickupEvent(taxiId, pickupLocation);
		//
		// sendDropoffEvent(taxiId, dropoffLocation, amount);
		//
		// advanceTimeBy(long seconds)
		//

	}

}
