package de.tud.stg

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object CountErrors {
  def main(args: Array[String]) = {
    val sc = new SparkContext("local[2]", "Count Errors")

    val log = sc.textFile("example.log", 2)
    val count = (log filter { _.toLowerCase contains "error" }).count

    println("========================================")
    println(s"$count errors")
    println("========================================")

    sc.stop
  }
}
