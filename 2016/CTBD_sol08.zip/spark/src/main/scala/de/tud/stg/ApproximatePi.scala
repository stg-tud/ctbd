package de.tud.stg

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object ApproximatePi {
  def main(args: Array[String]) = {
    val sc = new SparkContext("local[2]", "Approximate Pi")

    val samplesCount = 10000000
    val samples = sc parallelize (1 to samplesCount)

    val samplesInsideCircle = samples map { _ =>
      val x = math.random
      val y = math.random
      if (x * x + y * y < 1) 1 else 0
    } reduce { _ + _ }

    val pi = 4.0 * samplesInsideCircle / samplesCount

    println("========================================")
    println(s"Pi is approximately $pi")
    println("========================================")

    sc.stop
  }
}
