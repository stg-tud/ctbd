package de.tud.stg;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import java.io.IOException;
import java.util.*;

public class TwoStepJoin {

    private static class PersonalInformationMapper extends Mapper<LongWritable, Text, Text, Text> {

        private Text ssn = new Text();
        private Text city = new Text();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] line = value.toString().split(":");
            ssn.set(line[0]);
            city.set(line[1].split(";")[1]);
            context.write(ssn, city);
        }
    }

    private static class IncomeMapper extends Mapper<LongWritable, Text, Text, Text> {

        private Text ssn = new Text();
        private Text income = new Text();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] line = value.toString().split(":");
            ssn.set(line[0]);
            String[] years = line[1].split(",");
            for (String year: years) {
                String[] record = year.substring(1, year.length() - 1).split(";");
                if (record[0].equals("2007")) {
                    income.set(record[1]);
                    context.write(ssn, income);
                }
            }
        }
    }

    private static class CityIncomeReducer extends Reducer<Text, Text, Text, Text> {

        Text result = new Text();

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            String income = "";
            String city = "";
            Iterator<Text> iterator = values.iterator();
            while (iterator.hasNext()) {
                String next = iterator.next().toString();
                if (next.matches("\\d+")) {
                    income = next;
                } else {
                    city = next;
                }
            }

            result.set(city + "," + income);
            context.write(key, result);
        }
    }

    private static class CityIncomeMapper extends Mapper<LongWritable, Text, Text, Text> {

        Text city = new Text();
        Text income = new Text();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] record = value.toString().split("[\t,]");
            city.set(record[1]);
            income.set(record[2]);
            context.write(city, income);
        }
    }

    private static class CityAvgIncomeReducer extends Reducer<Text, Text, Text, Text> {

        Text averageIncome = new Text();

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            List<Long> incomes = new ArrayList<>();
            Iterator<Text> iterator = values.iterator();
            while(iterator.hasNext()) {
                Text next = iterator.next();
                incomes.add(Long.parseLong(next.toString()));
            }
            double avg = incomes.stream().mapToLong(Long::longValue).average().getAsDouble();
            averageIncome.set(Double.toString(avg));
            context.write(key, averageIncome);
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();

        Path inputPath1 = new Path(args[0]);
        Path inputPath2 = new Path(args[1]);
        Path outputPath1 = new Path(args[2]);

        FileSystem fs = FileSystem.get(conf);
        if (fs.exists(outputPath1)) {
            fs.delete(outputPath1, true);
        }

        Job job1 = Job.getInstance(conf, "Step 1");
        job1.setOutputKeyClass(Text.class);
        job1.setOutputValueClass(Text.class);
        MultipleInputs.addInputPath(job1, inputPath1, TextInputFormat.class, PersonalInformationMapper.class);
        MultipleInputs.addInputPath(job1, inputPath2, TextInputFormat.class, IncomeMapper.class);
        job1.setReducerClass(CityIncomeReducer.class);
        FileOutputFormat.setOutputPath(job1, outputPath1);

        job1.setJarByClass(TwoStepJoin.class);
        job1.waitForCompletion(true);

        Path outputPath2 = new Path(args[3]);
        if (fs.exists(outputPath2)) {
            fs.delete(outputPath2, true);
        }

        Job job2 = Job.getInstance(conf, "Step 2");
        job2.setOutputKeyClass(Text.class);
        job2.setOutputValueClass(Text.class);
        job2.setMapperClass(CityIncomeMapper.class);
        job2.setReducerClass(CityAvgIncomeReducer.class);

        job2.setInputFormatClass(TextInputFormat.class);
        job2.setOutputFormatClass(TextOutputFormat.class);

        FileInputFormat.addInputPath(job2, outputPath1);
        FileOutputFormat.setOutputPath(job2, outputPath2);

        job2.setJarByClass(TwoStepJoin.class);
        System.exit(job2.waitForCompletion(true) ? 0 : 1);
    }
}
