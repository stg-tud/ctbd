package exercise;

public class MySubscriber {

	public void update(int pickupLocation, int dropoffLocation, int sum) {
		System.out.println(
		    " --> OUTPUT: pickupLocation=" + pickupLocation + ", dropoffLocation=" + dropoffLocation + ", sum=" + sum);
	}

}