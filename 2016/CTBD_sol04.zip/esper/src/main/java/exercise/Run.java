package exercise;

public class Run {

	public static void main(String[] args) {
		final Exercise ex = new MyExerciseSolution();
		ex.runExercise();
	}

}
