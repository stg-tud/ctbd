package exercise;

import java.util.HashSet;
import java.util.Set;

public class MyExerciseSolution extends Exercise {

	@Override
	protected Set<String> generateIntermediateRules() {
		final Set<String> rules = new HashSet<>();
		final String rule = "insert into Route " +
		    "select " +
		    "pu.pickupLocation as pickupLocation, do.dropoffLocation as dropoffLocation, do.amount as amount " +
		    "from pattern [every pu=Pickup -> (do=Dropoff(taxiId = pu.taxiId) where timer:within(30 min))]";
		rules.add(rule);
		return rules;
	}

	@Override
	protected String generateOutputRule() {
		return "select " +
		    "pickupLocation, dropoffLocation, sum(amount) as sum " +
		    "from Route " +
		    "group by pickupLocation, dropoffLocation " +
		    "output all every 1 events " +
		    "order by sum desc " +
		    "limit 10";
	}

	@Override
	protected void generateIntermedateStreams() {
		generateStream("Route", "pickupLocation", "dropoffLocation", "amount");
	}

	@Override
	protected void sendEvents() {
		sendPickupEvent(10, 1);
		sendDropoffEvent(10, 2, 100);
		sendDropoffEvent(10, 3, 100);
		sendDropoffEvent(20, 3, 110);
		sendDropoffEvent(20, 3, 130);
		sendPickupEvent(20, 1);
		sendDropoffEvent(20, 3, 140);
		sendPickupEvent(30, 1);
		sendDropoffEvent(30, 3, 140);
		sendPickupEvent(40, 6);
		sendDropoffEvent(40, 7, 140);
	}

}
