package exercise;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.espertech.esper.client.Configuration;
import com.espertech.esper.client.ConfigurationOperations;
import com.espertech.esper.client.EPException;
import com.espertech.esper.client.EPServiceDestroyedException;
import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EPStatement;
import com.espertech.esper.client.time.CurrentTimeEvent;

public abstract class Exercise {
	private EPServiceProvider provider;

	public void runExercise() {
		createProvider();
		generateIntermedateStreams();
		initializeProvider();
		installIntermediateRules(generateIntermediateRules());
		installOutputRule(generateOutputRule());
		sendEvents();
		disposeProvider();
	}

	protected abstract Set<String> generateIntermediateRules();

	protected abstract String generateOutputRule();

	protected abstract void sendEvents();

	protected abstract void generateIntermedateStreams();

	protected final void advanceTimeBy(long seconds) {
		final long newTimeInMilli = provider.getEPRuntime().getCurrentTime() + seconds * 1000;
		provider.getEPRuntime().sendEvent(new CurrentTimeEvent(newTimeInMilli));
	}

	protected final void sendPickupEvent(int taxiId, int pickupLocation) {
		final Map<String, Object> attrMap = new HashMap<String, Object>();
		attrMap.put("taxiId", taxiId);
		attrMap.put("pickupLocation", pickupLocation);
		System.out.println("Sending Pickup(taxiId=" + taxiId + ", pickupLocation=" + pickupLocation + ")");
		provider.getEPRuntime().sendEvent(attrMap, "Pickup");
	}

	protected final void sendDropoffEvent(int taxiId, int dropoffLocation, int amount) {
		final Map<String, Object> attrMap = new HashMap<String, Object>();
		attrMap.put("taxiId", taxiId);
		attrMap.put("dropoffLocation", dropoffLocation);
		attrMap.put("amount", amount);
		System.out.println(
		    "Sending Dropoff(taxiId=" + taxiId + ", dropoffLocation=" + dropoffLocation + ", amount=" + amount + ")");
		provider.getEPRuntime().sendEvent(attrMap, "Dropoff");
	}

	protected final void generateStream(String name, String... attrs) {
		final ConfigurationOperations config = provider.getEPAdministrator().getConfiguration();
		final Map<String, Object> schema = new HashMap<String, Object>();
		for (final String attr : attrs) {
			schema.put(attr, "int");
		}
		config.addEventType(name, schema);
	}

	private final void createProvider() {
		final Configuration config = new Configuration();
		config.getEngineDefaults().getLogging().setEnableExecutionDebug(false);
		config.getEngineDefaults().getThreading().setInternalTimerEnabled(false);
		config.setMetricsReportingDisabled();

		final Map<String, Object> pickupSchema = new HashMap<String, Object>();
		pickupSchema.put("taxiId", "int");
		pickupSchema.put("pickupLocation", "int");
		config.addEventType("Pickup", pickupSchema);

		final Map<String, Object> dropoffSchema = new HashMap<String, Object>();
		dropoffSchema.put("taxiId", "int");
		dropoffSchema.put("dropoffLocation", "int");
		dropoffSchema.put("amount", "int");
		config.addEventType("Dropoff", dropoffSchema);

		provider = EPServiceProviderManager.getDefaultProvider(config);
	}

	private final void initializeProvider() {
		provider.initialize();
	}

	private final void disposeProvider() {
		provider.destroy();
	}

	private final void installOutputRule(String rule) {
		try {
			final EPStatement statement = provider.getEPAdministrator().createEPL(rule);
			statement.setSubscriber(new MySubscriber());
		} catch (EPException | EPServiceDestroyedException e) {
			e.printStackTrace();
		}
	}

	private final void installIntermediateRules(final Set<String> rules) {
		try {
			for (final String rule : rules) {
				provider.getEPAdministrator().createEPL(rule);
			}
		} catch (EPException | EPServiceDestroyedException e) {
			e.printStackTrace();
		}
	}

}
