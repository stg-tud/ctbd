package de.tud.stg;

import java.util.concurrent.locks.ReentrantLock;

public class Data {
	public Data(long id) {
		this.id = id;
		this.lock = new ReentrantLock();
	}

	final public long id;
	final public ReentrantLock lock;
}
