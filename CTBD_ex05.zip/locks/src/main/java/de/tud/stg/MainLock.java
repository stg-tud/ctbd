package de.tud.stg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MainLock {
	static boolean failed = false;

	public static void main(String[] args) {
		int numThreads = 5;
		Random random = new Random(0);
		List<Data> list = IntStream.range(0, 20).mapToObj(i -> new Data(i)).collect(Collectors.toList());
		List<Thread> threads = IntStream.range(0, numThreads).mapToObj(i -> runThread(list, random)).collect(Collectors.toList());

		threads.forEach(thread -> {
			try { thread.join(); }
			catch (InterruptedException e) { e.printStackTrace(); }
		});

		if (!failed)
		  System.out.println("finished successfully");
	}

	public static Thread runThread(List<Data> list, Random random) {
		List<Data> newList = new ArrayList<>(list);

		Thread thread = new Thread() {
			@Override
			public void run() {
				long time = System.currentTimeMillis();
				while (System.currentTimeMillis() - time < 2000) {
					Collections.shuffle(newList, random);
					lock(newList);
					if (!newList.stream().allMatch(data -> data.lock.isHeldByCurrentThread())) {
						failed = true;
						throw new AssertionError("not all Data objects locked");
					}
					unlock(newList);
				}
			}
		};
		thread.start();

		return thread;
	}

	public static void lock(List<Data> list) {
		// TODO implement locking for given list of data objects
		//      using the Data::lock method
	}

	public static void unlock(List<Data> list) {
		list.forEach(data -> data.lock.unlock());
	}
}
