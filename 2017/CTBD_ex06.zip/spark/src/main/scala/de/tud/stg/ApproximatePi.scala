package de.tud.stg

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object ApproximatePi {
  def main(args: Array[String]) = {
    val sc = new SparkContext("local[2]", "Approximate Pi")

    val samplesCount = 10000000
    val samples = sc parallelize (1 to samplesCount)

    val samplesInsideCircle: Int = ??? // TODO: implementation goes here

    val pi = 4.0 * samplesInsideCircle / samplesCount

    println("========================================")
    println(s"Pi is approximately $pi")
    println("========================================")

    sc.stop
  }
}
