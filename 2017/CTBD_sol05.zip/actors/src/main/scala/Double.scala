import akka.actor.{Actor, ActorSystem, Props}


case class Number(n: Int)

class DoublingActor extends Actor {
  def receive: Receive = {
    case Number(n) => println(s"Result of doubling $n: ${n*2}")
  }
}

object Double extends App {

  val system = ActorSystem("DoublerSystem")

  val doubler = system.actorOf(Props[DoublingActor], name = "doubler")

  doubler ! Number(5)
}
