package chat

import akka.actor.{ActorSystem, Props}
import chat.events.ClientEvents.{Login, Say}
import chat.actors.{ChatService, Client}


object Chat extends App {

  val system = ActorSystem("ChatSystem")

  val chat = system.actorOf(Props[ChatService], "chat")

//  val client1 = system.actorOf(Props(new Client("Alice", chat)), "client1")
  val client1 = system.actorOf(Props(classOf[Client], "Alice", chat))
  client1 ! Login

  client1 ! Say("Hello")

  Thread.sleep(1000)

  val client2 = system.actorOf(Props(new Client("Bob", chat)), "client2")
  client2 ! Login

  client2 ! Say("Hello back")
  client2 ! Say("Whats up?")

  Thread.sleep(1000)

  client1 ! Say("Still busy")
}
