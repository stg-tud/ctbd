package chat.actors

import akka.actor.{Actor, ActorRef}
import akka.event.Logging
import chat.events.ServerEvents.{ChatMessage, HistoryMessage, LoginMessage}

import scala.collection.mutable

class ChatService extends Actor {
  val sessions = new mutable.HashMap[String, ActorRef]
  val history = new StringBuilder

  def receive: Receive = {
    case LoginMessage(name) =>
      sessions += name -> sender
      if (history.nonEmpty)
        sender ! HistoryMessage(history.toString())
      history append s"User $name logged in.\n"

    case ChatMessage(from, msg) =>
      if (sessions.contains(from)) {
        history append s"$from: $msg\n"
        val receiver = sessions.collect {
          case s if s._1 != from => s._2
        }
        for (r <- receiver) {
          r ! ChatMessage(from, msg)
        }
      }

  }
}
