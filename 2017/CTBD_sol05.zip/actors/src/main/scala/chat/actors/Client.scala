package chat.actors

import akka.actor.{Actor, ActorRef}
import chat.events.ClientEvents.{Login, Logout, Say}
import chat.events.ServerEvents.{ChatMessage, HistoryMessage, LoginMessage, LogoutMessage}

class Client(name: String, chat: ActorRef) extends Actor {

  def receive: Receive = {
    case Login => chat ! LoginMessage(name)
    case Logout => chat ! LogoutMessage(self)
    case Say(msg) => chat ! ChatMessage(name, msg)

    case HistoryMessage(history) => println(s"$name, this is what happened so far:\n-----\n$history-----\n")
    case ChatMessage(from, msg) => println(s"@$name - $from: $msg")
  }
}
