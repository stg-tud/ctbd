package chat.events

import akka.actor.ActorRef

object ServerEvents {
  case class LoginMessage(username: String)
  case class LogoutMessage(client: ActorRef)
  case class HistoryMessage(history: String)
  case class ChatMessage(from: String, msg: String)
}