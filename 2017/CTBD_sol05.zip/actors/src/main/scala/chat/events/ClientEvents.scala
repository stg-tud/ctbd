package chat.events

object ClientEvents {
  case object Login
  case object Logout
  case class Say(msg: String)
}
