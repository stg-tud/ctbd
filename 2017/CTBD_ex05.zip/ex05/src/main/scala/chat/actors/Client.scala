package chat.actors

import akka.actor.{Actor, ActorRef}

class Client(name: String, chat: ActorRef) extends Actor {

  def receive: Receive = ???
}
