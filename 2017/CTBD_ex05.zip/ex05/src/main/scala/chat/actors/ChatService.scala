package chat.actors

import akka.actor.Actor

class ChatService extends Actor {

  def receive: Receive = ???
}
